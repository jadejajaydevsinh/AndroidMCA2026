<?php 
include "connect.php";

$sql="CREATE TABLE MARVEL(id INT(3) PRIMARY KEY,firstname varchar(30),lastname varchar(30),email varchar(30))";

if($conn -> query($sql) === TRUE)
{

    echo "<br> new table created";
}
else
    {

        echo "failed";
    }
$conn -> close();
?>