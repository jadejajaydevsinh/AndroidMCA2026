<?php

if(isset($_COOKIE["user1"]))
{
    echo "cookie 'user1' is set! <br>";
    echo "value:".$_COOKIE["user1"];
}
else
    {

        echo "failed";
    }
?>