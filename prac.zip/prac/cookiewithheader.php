<?php

Setcookie("avengers","thor",time()+360,"/");

header("location:welcome.php");
exit();
?>