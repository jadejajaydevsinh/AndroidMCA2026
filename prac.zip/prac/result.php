<?php


    define("SUBJECT1","maths");
    define("SUBJECT2","hindi");
    define("SUBJECT3","english");

    $sub1=85;
    $sub2=77;
    $sub3=80;

    $total=$sub1+$sub2+$sub3;
    $per=($total/300) * 100;
    echo "result";
    echo "<br>";
    echo SUBJECT1.$sub1;
    echo "<br>";
    echo SUBJECT2.$sub2;
    echo "<br>";
    echo SUBJECT3.$sub3;
    echo "<br>";
    echo "total marks:".$total;
    echo "<br>";
    echo "percentage:".number_format($per)."%";
?>