<?php

    $a=10;
    $b=20;


    echo "ad:"($a+$b)."<br>";
    echo "su:"($a-$b)."<br>";
    echo "mu:"($a*$b)."<br>";
    echo "di:"($a/$b)."<br>";
    echo "mo:"($a%$b)."<br>";


    //asingment.
    echo "assignment:".$a."<br>";

    echo "a is equl to b"($a==$b?"yes":"no")."<br>";

    $a++;

    echo $a;

    $b--;

    echo $b;

?>