<?php

    session_start();

    $_SESSION["username"]="virat";
    $_SESSION["email"]="virat18@gmail.com";
     echo "seasion created";

     echo "<pre>";
     print_r(value:$_SESSION);
      echo "</pre>";

?>