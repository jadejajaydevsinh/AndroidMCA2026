<?php
    $i=2;
    while($i<=8)
    {
        echo $i."<br>";
        $i++;
    }

    $a=12;
    do{
        echo $a."<br>";
        $a++;
    }
    while($a<=17);
?>