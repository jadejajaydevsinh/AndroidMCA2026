<?php

include "connect.php";

$sql="DELETE FROM student where rollno=0";

if($conn -> query($sql) === TRUE)
{

    echo "<br> record deleted";
}
else
    {

        echo "failed";
    }
$conn -> close();
?>