<?php

    $server="localhost";
    $username="root";
    $password="";
    $dbms="stud";


    $conn=new mysqli($server,$username,$password,$dbms);

    if(!$conn)
    {

        die("failed");
    }
    else
    {
        echo "connected";

    }
?>