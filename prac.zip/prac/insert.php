<?php

include "connect.php";

$sql="INSERT INTO student(rollno,name, age, email, city) VALUES (2,'jay',17,'jay@gmail.com','morbi')";

if($conn -> query($sql) === TRUE)
{

    echo "<br> new record inserted";
}
else
    {

        echo "failed";
    }
$conn -> close();
?>