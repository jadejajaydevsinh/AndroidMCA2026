<?php

Setcookie("user1","viratkohli",time()+360,"/");
?>