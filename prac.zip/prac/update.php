<?php

include "connect.php";

$sql="UPDATE student SET name='rahul',age=22 where rollno=1";

if($conn -> query($sql) === TRUE)
{

    echo "<br> record updated";
}
else
    {

        echo "failed";
    }
$conn -> close();
?>