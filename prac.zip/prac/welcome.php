<?php
if(isset($_COOKIE["avengers"]))
{
    echo "cookie is set welcome".$_COOKIE['avengers'];
   
}
else
    {

        echo "fno cookie found";
    }

    ?>