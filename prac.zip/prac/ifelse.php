<?php

    $month="dec";

    if($month == "jan")
    {
        echo "This is jan";
    }
    elseif($month == "fab")
    {
        echo "This is fab";
    }
    elseif($month == "mar")
    {
        echo "This is mar ";
    }
    elseif($month == "apr")
    {
        echo "This is apr";
    }
    elseif($month == "may")
    {
        echo "This is may";
    }
    elseif($month == "jun")
    {
        echo "This is jun";
    }
    elseif($month == "jul")
    {
        echo "This is jul";
    }
    elseif($month == "aug")
    {
        echo "This is aug";
    }
    elseif($month == "sep")
    {
        echo "This is sep";
    }
    elseif($month == "oct")
    {
        echo "This is oct";
    }
    elseif($month == "nov")
    {
        echo "This is nov";
    }
    elseif($month == "dec")
    {
        echo "This is dec";
    }
    else
    {
        echo "wrong month";
    }


?>