<?php

    for($i=3;$i<=8;$i++)
    {

            echo $i."<br>";
    }
    $numbers=range(12,17);
    foreach($numbers as $number)
    {
        echo $number."<br>";
    }

?>